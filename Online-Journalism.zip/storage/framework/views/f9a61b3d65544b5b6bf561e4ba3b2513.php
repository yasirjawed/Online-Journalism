<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Admin Panel</div>
                <a class="nav-link <?php echo e(Request::Is('admin/dashboard')?'active':''); ?>" href="<?php echo e(url('admin/dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <a class="nav-link" href="index.html">
                    <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                   Profile
                </a>
                <a class="nav-link collapsed  <?php echo e(Request::Is('admin/add-category') || Request::Is('admin/category') || Request::Is('admin/edit-category/*') ? 'active':''); ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-layer-group"></i></div>
                    Category
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo e(Request::Is('admin/add-category')?'active':''); ?>" href="<?php echo e(url('admin/add-category')); ?>">Add Category</a>
                        <a class="nav-link <?php echo e(Request::Is('admin/category') || Request::Is('admin/edit-category/*') ?'active':''); ?>" href="<?php echo e(url('admin/category')); ?>">View Category</a>
                    </nav>
                </div>
                <a class="nav-link collapsed <?php echo e(Request::Is('admin/add-post') || Request::Is('admin/post') || Request::Is('admin/post/*') ? 'show active':''); ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapsepost" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-blog"></i></div>
                    Posts
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapsepost" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo e(Request::Is('admin/add-post')?'active':''); ?>" href="<?php echo e(url('admin/add-post')); ?>">Add Posts</a>
                        <a class="nav-link <?php echo e(Request::Is('admin/post') || Request::Is('admin/post/*') ?'active':''); ?>" href="<?php echo e(url('admin/post')); ?>">View Posts</a>
                    </nav>
                </div>

                <a class="nav-link" href="index.html">
                    <div class="sb-nav-link-icon"><i class="fas fa-address-book"></i></div>
                    Blog Approval Requests
                </a>
                <a class="nav-link <?php echo e(Request::Is('admin/users')?'active':''); ?>" href="<?php echo e(url('admin/users')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    User Management
                </a>

            </div>
        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            Arsalan Siddiqui
        </div>
    </nav>
</div>
<?php /**PATH D:\xampp\htdocs\larablog\resources\views/layouts/inc/admin-sidebar.blade.php ENDPATH**/ ?>