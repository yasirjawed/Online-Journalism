<?php $__env->startSection('title','Admin Edit Post'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
    <div class="card mt-4">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
        <div class="card-header">

           <h4>Edit Post</h4>
        </div>
        <div class="card-body">

            <form action="<?php echo e(url('admin/update-post-approval/'.$posts->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                    <label for="">Category</label>
                    <select name="category_id" id="" required class="form-control">
                        <option value="">-- SELECT CATEGORY --</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id==$posts->category_id): ?>
                                <option value="<?php echo e($item->id); ?>" selected><?php echo e($item->name); ?></option>
                            <?php else: ?>
                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </select>
                </div>
                <div class="mb-3">
                    <label for="">Post Name</label>
                    <input type="text" name="name" value="<?php echo e($posts->name); ?>" class="form-control">
                </div>
                <div class="mb-3">
                    <label for="">Slug</label>
                    <input type="text" name="slug" class="form-control" value="<?php echo e($posts->slug); ?>">
                </div>
                <div class="mb-3">
                    <label for="">Description</label>
                    <textarea name="description" rows="5" id="MySummerNote" class="form-control"><?php echo $posts->description; ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="">Youtube Iframe Link</label>
                    <input type="text" name="yt_iframe" class="form-control" value="<?php echo e($posts->yt_iframe); ?>">
                </div>
                <h6>SEO TAGS</h6>
                <div class="mb-3">
                    <label for="">Meta Title</label>
                    <input type="text" name="meta_title" class="form-control" value="<?php echo e($posts->meta_title); ?>">
                </div>
                <div class="mb-3">
                    <label for="">Meta Description</label>
                    <textarea name="meta_description" rows="3" class="form-control"><?php echo $posts->meta_description; ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="">Meta Keywords</label>
                    <textarea name="meta_keyword" rows="3" class="form-control"><?php echo $posts->meta_keyword; ?></textarea>
                </div>
                <h6>STATUS MODE</h6>
                <div class="row">

                    <div class="col-md-3 mb-3 d-none">
                        <label for="">Hidden</label>
                        <input type="checkbox" name="status" <?php echo e($posts->status=='1' ? 'checked':''); ?>>
                    </div>
                    <div class="col-md-12 mb-12">
                        <label for="">Process_Status</label>
                        <select name="active_status" id="active_status" class="form-control">
                            <option value="0">Pending</option>
                            <option value="1">Accepted</option>
                            <option value="2">Rejected</option>
                        </select>
                    </div>
                    <div class="col-md-12 mb-12" style="display:none" id="process_description">
                        <label for="">Rejection Purpose</label>
                        <textarea name="Rejection" id="MySummerNote" rows="5" class="form-control"></textarea>
                    </div>
                    <div class="col-md-12 mt-5">
                        <button class="btn btn-primary" type="submit">Save Category</button>
                    </div>
                </div>







            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Online-Journalism\resources\views/admin/approval/process.blade.php ENDPATH**/ ?>