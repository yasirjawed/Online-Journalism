<?php $__env->startSection('title','Admin Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>
    <div class="row">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">Total Users</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <?php echo e($totaluserCount); ?>

                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">Total Posts</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <?php echo e($totalpostCount); ?>

                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">Total Categories</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <?php echo e($totalcategoryCount); ?>

                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">Total Post Pending Approval</div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <?php echo e($pendingcount); ?>

                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>

    </div>
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            <b> User Tables</b>
        </div>
        <div class="card-body">
            <table id="datatablesSimple">
                <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Joined At</th>
                        <th>Role</th>
                        <th>Edit</th>
                      
                    </tr>
                </thead>
               
                <tbody>
                    <?php $__currentLoopData = $TotalUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->created_at->format('d-m-Y')); ?></td>
                        <td><?php echo e($user->role_as=='1'?'Admin':'User'); ?></td>
                        <td><a href="<?php echo e(url('admin/users/'.$user->id)); ?>" class="btn btn-success">Edit</a></td>
                      
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    
                </tbody>
            </table>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
           <b>Post Pending For Approval</b>
        </div>
        <div class="card-body">
            <table id="datatablesSimple2">
                <thead>
                    <tr>
                        <th>Person Name</th>
                        <th>Category</th>
                        <th>Post Title</th>
                        <th>Edit</th>
                      
                    </tr>
                </thead>
               
                <tbody>
                    <?php $__currentLoopData = $pedningApproval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedningrequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($pedningrequest->user->name); ?></td>
                        <td><?php echo e($pedningrequest->category->name); ?></td>
                        <td><?php echo e($pedningrequest->name); ?></td>
                        <td><a href="<?php echo e(url('admin/post/'.$pedningrequest->id)); ?>" class="btn btn-success">Edit</a></td>
                      
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Online-Journalism\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>