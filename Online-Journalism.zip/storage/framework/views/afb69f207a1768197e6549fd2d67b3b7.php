<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Admin Panel</div>
                <a class="nav-link <?php echo e(Request::Is('journalist/dashboard')?'active':''); ?>" href="<?php echo e(url('journalist/dashboard')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Dashboard
                </a>
                <a class="nav-link <?php echo e(Request::Is('journalist/profile')?'active':''); ?>" href="<?php echo e(url('journalist/profile')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Profile
                </a>
                <a class="nav-link" href="<?php echo e(url('/')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Online Journalism Website
                </a>
                <a class="nav-link collapsed <?php echo e(Request::Is('journalist/add-post') || Request::Is('admin/post') || Request::Is('admin/post/*') ? 'show active':''); ?>" href="#" data-bs-toggle="collapse" data-bs-target="#collapsepost" aria-expanded="false" aria-controls="collapseLayouts">
                    <div class="sb-nav-link-icon"><i class="fas fa-blog"></i></div>
                    Posts
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapsepost" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link <?php echo e(Request::Is('journalist/add-post')?'active':''); ?>" href="<?php echo e(url('journalist/add-post')); ?>">Add Posts</a>
                        <a class="nav-link <?php echo e(Request::Is('journalist/post') || Request::Is('journalist/post/*') ?'active':''); ?>" href="<?php echo e(url('journalist/post')); ?>">View Posts</a>
                    </nav>
                </div>
                <a class="nav-link <?php echo e(Request::Is('journalist/pending_post')?'active':''); ?>" href="<?php echo e(url('journalist/pending_post')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Pending Post
                </a>
                <a class="nav-link <?php echo e(Request::Is('journalist/rejected_post')?'active':''); ?>" href="<?php echo e(url('journalist/rejected_post')); ?>">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Rejected Post <span style="color: red"> <?php Session::get('variableName'); ?></span>
                </a>
            </div>

        </div>
        <div class="sb-sidenav-footer">
            <div class="small">Logged in as:</div>
            Arsalan Siddiqui
        </div>
    </nav>
</div>
<?php /**PATH D:\xampp\htdocs\Online-Journalism\resources\views/layouts/inc/journalist-sidebar.blade.php ENDPATH**/ ?>