<?php $__env->startSection('title','View Posts'); ?>
<?php $__env->startSection('content'); ?>

    <div class="container-fluid px-4">
        <div class="card mt-4">

            <div class="card-header">
                <h4>Rejected Posts
                
            </div>
            <div class="card-body">
                <?php if(session('message')): ?>
                <div class="alert alert-success"><?php echo e(session('message')); ?></div>
            <?php endif; ?>
            <table class="table table-bordered" id="myDataTable">
                <thead>
                    <td style="width:10%">ID</td>
                    <td style="width:20%">Category</td>
                    <td style="width:40%">Post Name</td>

                    <td style="width:10%">Status</td>
                    <td style="width:10%">Edit</td>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->category->name); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->active_status=='2'?'Rejected':''); ?></td>
                            <td><a href="<?php echo e(url('journalist/post/'.$item->id)); ?>" class="btn btn-success">ReSubmit</a></td>


                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.masters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Online-Journalism\resources\views/journalist/post/rejected_post.blade.php ENDPATH**/ ?>