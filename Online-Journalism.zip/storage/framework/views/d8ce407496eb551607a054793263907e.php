<?php $__env->startSection('content'); ?>
<h4>hello world</h4>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\larablog\resources\views/frontend/index.blade.php ENDPATH**/ ?>