<?php $__env->startSection('title','Admin Category'); ?>
<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
       Post Pending For Approval
    </div>
    <div class="card-body">
        <table id="datatablesSimple2">
            <thead>
                <tr>
                    <th>Person Name</th>
                    <th>Category</th>
                    <th>Post Title</th>
                    <th>Edit</th>

                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $pedningApproval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedningrequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($pedningrequest->user->name); ?></td>
                    <td><?php echo e($pedningrequest->category->name); ?></td>
                    <td><?php echo e($pedningrequest->name); ?></td>
                    <td><a href="<?php echo e(url('admin/approval/'.$pedningrequest->id)); ?>" class="btn btn-success">Edit</a></td>


                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Online-Journalism\resources\views/admin/approval/index.blade.php ENDPATH**/ ?>