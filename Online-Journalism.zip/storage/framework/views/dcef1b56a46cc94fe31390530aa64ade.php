<?php $__env->startSection('title','Admin Add Post'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-fluid px-4">
    <div class="card mt-4">
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div><?php echo e($error); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
        <div class="card-header">

           <h4>Add Post</h4>
        </div>


        <div class="card-body">


            <form action="<?php echo e(url('journalist/update-profile')); ?>" method="POST" enctype="multipart/form-data">
                <?php if(session('message')): ?>
                    <div class="alert alert-success"><?php echo e(session('message')); ?></div>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                    <label for="">Biography</label>
                    <textarea name="Biography" id="" rows="5" class="form-control"><?php echo e($userprofile->biography); ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="">Mission</label>
                    <textarea name="Mission" id="" rows="2" class="form-control"><?php echo e($userprofile->mission); ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="">What am i doing now</label>
                    <textarea name="Now" id="" rows="2" class="form-control"><?php echo e($userprofile->now); ?></textarea>
                </div>

                <div class="row">


                    <div class="col-md-12 mt-5">
                        <button class="btn btn-primary" type="submit">Update Profile</button>
                    </div>
                </div>







            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.masters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Online-Journalism\resources\views/journalist/profile/profile.blade.php ENDPATH**/ ?>