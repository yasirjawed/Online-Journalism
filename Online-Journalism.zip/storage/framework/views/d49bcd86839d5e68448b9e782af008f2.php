<?php $__env->startSection('content'); ?>
<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div class="category-heading">
                    <h4><?php echo e($category->name); ?></h4>
                </div>

                    <?php $__empty_1 = true; $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="card card-shadow mt-4" >
                            <div class="card-body">
                                <a href="<?php echo e(url('tutorial/'.$category->slug . '/' . $postitem->slug)); ?>" class="text-decoration-none">
                                   <h4 class="post-heading"><?php echo e($postitem->name); ?></h4>
                                </a>
                                <h6>
                                    Posted On: <?php echo e($postitem->created_at->format('d-m-Y')); ?>

                                    <span class="ms-3">Posted By: <?php echo e($postitem->user->name); ?></span>
                                </h6>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="card card-shadow mt-4" >
                            <div class="card-body">
                                <h1 >No Post Found</h1>
                            </div>
                        </div>
                    <?php endif; ?>

            </div>
            <div class="col-md-3">
                <div class="border p-2">

                    <h4>Advertising Area</h4>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\larablog\resources\views/frontend/post/index.blade.php ENDPATH**/ ?>