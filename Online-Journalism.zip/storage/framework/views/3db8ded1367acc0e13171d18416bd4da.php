<div class="golbal-navbar">

    <nav class="navbar navbar-expand-lg" style="background-color: #000000;width: 100%">


        <div class="collapse navbar-collapse" id="navbarSupportedContent">

          <ul class="navbar-nav navbar-center mr-auto hiding-case-class" style="">
            <li class="nav-item active">
              <a class="nav-link" href="<?php echo e(url('/')); ?>">Home <span class="sr-only"></span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo e(url('/correspondents')); ?>">Correspondents</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/collections')); ?>">Collections</a>
              </li>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/listen')); ?>">Listen</a>
            </li>

          </ul>

          <a class="navbar-brand navbar-logo-class" href="#"><img src="<?php echo e(url('images/logo-nav.png')); ?>" id="logo-navbar" class="image-fluid" style="display:none"></a>
            <?php if(Auth::check()): ?>

                <button type="button" class="btn  button-nav" ><a href="/<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" style="">Logout</a></button>
                <form action="<?php echo e(route('logout')); ?>" id="logout-form" class="d-none" method="post">
                    <?php echo csrf_field(); ?>
                </form>

                <?php if(Auth::user()->role_as=='1'): ?>
                    <button type="button" class="btn  button-nav2" ><a href="<?php echo e(url('admin/dashboard')); ?>" style="">Dashboard</a></button>
                <?php elseif(Auth::user()->role_as=='0'): ?>
                     <?php else: ?>
                    <button type="button" class="btn  button-nav2" ><a href="<?php echo e(url('journalist/dashboard')); ?>" style="">Dashboard</a></button>
                <?php endif; ?>
            <?php else: ?>
                <button type="button" class="btn  button-nav" ><a href="<?php echo e(url('/login')); ?>" style="">Login / Signup</a></button>
            <?php endif; ?>




        </div>
      </nav>
      <input type="checkbox" id="openSidebarMenu">
      <label for="openSidebarMenu" class="sidebarIconToggle" style="position:fixed">
          <div class="spinner top"></div>
          <div class="spinner middle"></div>
          <div class="spinner bottom"></div>
      </label>
      <div id="sidebarMenu">
          <ul class="menu">
              <li style=""><a  href="<?php echo e(url('/')); ?>">Home<i class="fa-solid fa-chevron-right" style="color: #c62a2a;text-align:end;float: right "></i></a></li>
              <li><a  href="<?php echo e(url('/correspondents')); ?>">Correspondents<i class="fa-solid fa-chevron-right" style="color: #c62a2a;text-align:end;float: right "></i></a></li>
              <li><a  href="<?php echo e(url('/collections')); ?>">Collections<i class="fa-solid fa-chevron-right" style="color: #c62a2a;text-align:end;float: right "></i></a></li>
              <li><a  href="<?php echo e(url('/listen')); ?>">Listen<i class="fa-solid fa-chevron-right" style="color: #c62a2a;text-align:end;float: right "></i></a></li>
              <li><a  href="<?php echo e(url('/founding_principles')); ?>">Founding Principles<i class="fa-solid fa-chevron-right" style="color: #c62a2a;text-align:end;float: right "></i></a></li>
          </ul>
          <ul class="menu2">
              <li style=""><a href="<?php echo e(url('/Contact_us')); ?>">Contact</a></li>
              <li><a href="<?php echo e(url('/about_us')); ?>">About Us</a></li>
              <li><a href="<?php echo e(url('/terms_condition')); ?>">Terms And Conditions</a></li>
              <li><a href="<?php echo e(url('/privacy_policy')); ?>">Privacy Policy</a></li>
              <li><a href="<?php echo e(url('/values_rules')); ?>">Values</a></li>
              <li style="border-bottom: 2px solid black"><a href="<?php echo e(url('/faq_list')); ?>">Frequently Asked Questions</a></li>
              <?php if(Auth::check()): ?>

              <li><a href="/<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();" style="">Logout</a></li>
              <form action="<?php echo e(route('logout')); ?>" id="logout-form" class="d-none" method="post">
                  <?php echo csrf_field(); ?>
              </form>

              <?php if(Auth::user()->role_as=='1'): ?>
              <li><a href="<?php echo e(url('admin/dashboard')); ?>" style="">Dashboard</a></li>
              <?php elseif(Auth::user()->role_as=='0'): ?>
                   <?php else: ?>
                   <li><a href="<?php echo e(url('journalist/dashboard')); ?>" style="">Dashboard</a></li>
              <?php endif; ?>
          <?php else: ?>
          <li ><a href="<?php echo e(url('/login')); ?>" style="">Login / Signup</a></li>
          <?php endif; ?>

          </ul>
      </div>

</div>
<?php /**PATH D:\xampp\htdocs\Online-Journalism\resources\views/layouts/inc/frontend-navbar.blade.php ENDPATH**/ ?>