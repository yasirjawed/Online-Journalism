<?php echo e($slot); ?>

<?php /**PATH D:\xampp\htdocs\Online-Journalism\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>