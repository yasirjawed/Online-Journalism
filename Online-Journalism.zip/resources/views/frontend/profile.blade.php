
@extends('layouts.app')
@section('title',"Online Journalism")
@section('meta_description',"Online Journalism")
@section('meta_keyword',"Online Journalism")
@section("script")
<style>
    #main-img-display{
        max-width: 100%;
        height: auto;
    }
    #main-img-display3{
        max-width: 100%;
        height: auto;
        margin-top: -65px
    }
    @media only screen and (min-width: 300px) and (max-width: 991px) {
        .info{
            padding: 50px !important;
        }

    }
    @media only screen and (min-width: 100px) and (max-width: 1100px) {
        .heda{
            padding: 0px !important;
        }


    }
    @media only screen and (min-width: 100px) and (max-width: 991px) {


        #posts-section{
            display:none;
        }
       .btn-group{
            display:block !important;
        }
        .padd-cell{
            padding: 50px;
        }

    }

</style>
@section('content')

    <div class="container-fluid" style="background-color:#caddee;padding-bottom:150px">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"  style="display:grid;justify-content: center;">
                    <img src="{{url('images/logo-nav-new.png')}}" id="main-img-display2" class="image-fluid">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"  style="justify-content: center;margin-top:-96px">
                    <h1>Frequently Asked Questions (FAQ)</h1>
            </div>

        </div>
    </div>
    <div class="container-fluid info" style="background-color:white;margin-top:-80px;max-width:900px;font-style: italic;font-size:18px">

        <div class="row " style="border:1px solid black">
            {{-- <div class="btn-group" style="width: 100%;margin:0;padding:0;display: none"> --}}
                <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 btn-group"  style="background-color:black;color:white;text-align:center;padding:0;margin:0;display: none" >
                    <button class="post-btn" style="width:100%"> Posts</button>
                </div>
                <div class="col-lg-12 col-md-6 col-sm-6 col-xs-6 btn-group"  style="background-color:black;color:white;text-align:center;padding:0;margin:0;display: none">
                    <button class="biography-btn" style="width:100%">Biography</button>
                </div>
            {{-- </div> --}}
            <div class="col-lg-8 col-md-12 col-sm-12" id="posts-section" style="background-color: ddd;">
                <h1 style="color:rgb(109, 7, 7)">- All Posts</h1>
                @foreach ($all_post as $Latest_Posts_per)
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p-5 nopad">
                        <a href="{{url('tutorial/'.$Latest_Posts_per->category->slug.'/'.$Latest_Posts_per->slug)}}" class="text-decoration-none">
                            <div class="card">
                                <img class="card-img-top" src="{{url('images/blogs.jpg')}}" alt="Card image cap">
                                <div class="card-body blogs">
                                    <div class="col-md-12">
                                        <h6 class="card-title" class="top-name" style="color: black">{{\Illuminate\Support\Str::limit($user->biography, 150, $end='...') }}</h6>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6" style="margin:auto 0;color:black !important">
                                            <h6 style="font-size:15px" style="color:black !important">Created On:{{$Latest_Posts_per->created_at->format('d-m-y')}}</h6>
                                        </div>
                                        <div class="col-md-6 ">
                                            <div class="row">
                                                <div class="col-md-12 text-center" style="margin:auto 0">
                                                    <img src="{{url('images/persons.png')}}" class="person" alt="" class="person-img">
                                                </div>
                                                <div class="col-md-12 text-center" style="margin:auto 0">
                                                    <p class="card-title" >- {{$Latest_Posts_per->user->name}}</p>
                                                </div>
                                            </div>
                                        </div>

                                    </div>


                                </div>
                            </div>
                        </a>
                    </div>
                @endforeach
                @foreach ($all_post as $Latest_Posts_per)
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p-5 nopad">
                    <a href="{{url('tutorial/'.$Latest_Posts_per->category->slug.'/'.$Latest_Posts_per->slug)}}" class="text-decoration-none">
                        <div class="card">
                            <img class="card-img-top" src="{{url('images/blogs.jpg')}}" alt="Card image cap">
                            <div class="card-body blogs">
                                <div class="col-md-12">
                                    <h6 class="card-title" class="top-name" style="color: black">{{\Illuminate\Support\Str::limit($user->biography, 150, $end='...') }}</h6>
                                </div>
                                <div class="row">
                                    <div class="col-md-6" style="margin:auto 0;color:black !important">
                                        <h6 style="font-size:15px" style="color:black !important">Created On:{{$Latest_Posts_per->created_at->format('d-m-y')}}</h6>
                                    </div>
                                    <div class="col-md-6 ">
                                        <div class="row">
                                            <div class="col-md-12 text-center" style="margin:auto 0">
                                                <img src="{{url('images/persons.png')}}" class="person" alt="" class="person-img">
                                            </div>
                                            <div class="col-md-12 text-center" style="margin:auto 0">
                                                <p class="card-title" >- {{$Latest_Posts_per->user->name}}</p>
                                            </div>
                                        </div>
                                    </div>

                                </div>


                            </div>
                        </div>
                    </a>
                </div>
            @endforeach
            @foreach ($all_post as $Latest_Posts_per)
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p-5 nopad">
                <a href="{{url('tutorial/'.$Latest_Posts_per->category->slug.'/'.$Latest_Posts_per->slug)}}" class="text-decoration-none">
                    <div class="card">
                        <img class="card-img-top" src="{{url('images/blogs.jpg')}}" alt="Card image cap">
                        <div class="card-body blogs">
                            <div class="col-md-12">
                                <h6 class="card-title" class="top-name" style="color: black">{{\Illuminate\Support\Str::limit($user->biography, 150, $end='...') }}</h6>
                            </div>
                            <div class="row">
                                <div class="col-md-6" style="margin:auto 0;color:black !important">
                                    <h6 style="font-size:15px" style="color:black !important">Created On:{{$Latest_Posts_per->created_at->format('d-m-y')}}</h6>
                                </div>
                                <div class="col-md-6 ">
                                    <div class="row">
                                        <div class="col-md-12 text-center" style="margin:auto 0">
                                            <img src="{{url('images/persons.png')}}" class="person" alt="" class="person-img">
                                        </div>
                                        <div class="col-md-12 text-center" style="margin:auto 0">
                                            <p class="card-title" >- {{$Latest_Posts_per->user->name}}</p>
                                        </div>
                                    </div>
                                </div>

                            </div>


                        </div>
                    </div>
                </a>
            </div>
        @endforeach
        @foreach ($all_post as $Latest_Posts_per)
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p-5 nopad">
            <a href="{{url('tutorial/'.$Latest_Posts_per->category->slug.'/'.$Latest_Posts_per->slug)}}" class="text-decoration-none">
                <div class="card">
                    <img class="card-img-top" src="{{url('images/blogs.jpg')}}" alt="Card image cap">
                    <div class="card-body blogs">
                        <div class="col-md-12">
                            <h6 class="card-title" class="top-name" style="color: black">{{\Illuminate\Support\Str::limit($user->biography, 150, $end='...') }}</h6>
                        </div>
                        <div class="row">
                            <div class="col-md-6" style="margin:auto 0;color:black !important">
                                <h6 style="font-size:15px" style="color:black !important">Created On:{{$Latest_Posts_per->created_at->format('d-m-y')}}</h6>
                            </div>
                            <div class="col-md-6 ">
                                <div class="row">
                                    <div class="col-md-12 text-center" style="margin:auto 0">
                                        <img src="{{url('images/persons.png')}}" class="person" alt="" class="person-img">
                                    </div>
                                    <div class="col-md-12 text-center" style="margin:auto 0">
                                        <p class="card-title" >- {{$Latest_Posts_per->user->name}}</p>
                                    </div>
                                </div>
                            </div>

                        </div>


                    </div>
                </div>
            </a>
        </div>
    @endforeach
    @foreach ($all_post as $Latest_Posts_per)
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p-5 nopad">
        <a href="{{url('tutorial/'.$Latest_Posts_per->category->slug.'/'.$Latest_Posts_per->slug)}}" class="text-decoration-none">
            <div class="card">
                <img class="card-img-top" src="{{url('images/blogs.jpg')}}" alt="Card image cap">
                <div class="card-body blogs">
                    <div class="col-md-12">
                        <h6 class="card-title" class="top-name" style="color: black">{{\Illuminate\Support\Str::limit($user->biography, 150, $end='...') }}</h6>
                    </div>
                    <div class="row">
                        <div class="col-md-6" style="margin:auto 0;color:black !important">
                            <h6 style="font-size:15px" style="color:black !important">Created On:{{$Latest_Posts_per->created_at->format('d-m-y')}}</h6>
                        </div>
                        <div class="col-md-6 ">
                            <div class="row">
                                <div class="col-md-12 text-center" style="margin:auto 0">
                                    <img src="{{url('images/persons.png')}}" class="person" alt="" class="person-img">
                                </div>
                                <div class="col-md-12 text-center" style="margin:auto 0">
                                    <p class="card-title" >- {{$Latest_Posts_per->user->name}}</p>
                                </div>
                            </div>
                        </div>

                    </div>


                </div>
            </div>
        </a>
    </div>
@endforeach
@foreach ($all_post as $Latest_Posts_per)
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p-5 nopad">
    <a href="{{url('tutorial/'.$Latest_Posts_per->category->slug.'/'.$Latest_Posts_per->slug)}}" class="text-decoration-none">
        <div class="card">
            <img class="card-img-top" src="{{url('images/blogs.jpg')}}" alt="Card image cap">
            <div class="card-body blogs">
                <div class="col-md-12">
                    <h6 class="card-title" class="top-name" style="color: black">{{\Illuminate\Support\Str::limit($user->biography, 150, $end='...') }}</h6>
                </div>
                <div class="row">
                    <div class="col-md-6" style="margin:auto 0;color:black !important">
                        <h6 style="font-size:15px" style="color:black !important">Created On:{{$Latest_Posts_per->created_at->format('d-m-y')}}</h6>
                    </div>
                    <div class="col-md-6 ">
                        <div class="row">
                            <div class="col-md-12 text-center" style="margin:auto 0">
                                <img src="{{url('images/persons.png')}}" class="person" alt="" class="person-img">
                            </div>
                            <div class="col-md-12 text-center" style="margin:auto 0">
                                <p class="card-title" >- {{$Latest_Posts_per->user->name}}</p>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </div>
    </a>
</div>
@endforeach
@foreach ($all_post as $Latest_Posts_per)
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p-5 nopad">
    <a href="{{url('tutorial/'.$Latest_Posts_per->category->slug.'/'.$Latest_Posts_per->slug)}}" class="text-decoration-none">
        <div class="card">
            <img class="card-img-top" src="{{url('images/blogs.jpg')}}" alt="Card image cap">
            <div class="card-body blogs">
                <div class="col-md-12">
                    <h6 class="card-title" class="top-name" style="color: black">{{\Illuminate\Support\Str::limit($user->biography, 150, $end='...') }}</h6>
                </div>
                <div class="row">
                    <div class="col-md-6" style="margin:auto 0;color:black !important">
                        <h6 style="font-size:15px" style="color:black !important">Created On:{{$Latest_Posts_per->created_at->format('d-m-y')}}</h6>
                    </div>
                    <div class="col-md-6 ">
                        <div class="row">
                            <div class="col-md-12 text-center" style="margin:auto 0">
                                <img src="{{url('images/persons.png')}}" class="person" alt="" class="person-img">
                            </div>
                            <div class="col-md-12 text-center" style="margin:auto 0">
                                <p class="card-title" >- {{$Latest_Posts_per->user->name}}</p>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </div>
    </a>
</div>
@endforeach
@foreach ($all_post as $Latest_Posts_per)
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 p-5 nopad">
    <a href="{{url('tutorial/'.$Latest_Posts_per->category->slug.'/'.$Latest_Posts_per->slug)}}" class="text-decoration-none">
        <div class="card">
            <img class="card-img-top" src="{{url('images/blogs.jpg')}}" alt="Card image cap">
            <div class="card-body blogs">
                <div class="col-md-12">
                    <h6 class="card-title" class="top-name" style="color: black">{{\Illuminate\Support\Str::limit($user->biography, 150, $end='...') }}</h6>
                </div>
                <div class="row">
                    <div class="col-md-6" style="margin:auto 0;color:black !important">
                        <h6 style="font-size:15px" style="color:black !important">Created On:{{$Latest_Posts_per->created_at->format('d-m-y')}}</h6>
                    </div>
                    <div class="col-md-6 ">
                        <div class="row">
                            <div class="col-md-12 text-center" style="margin:auto 0">
                                <img src="{{url('images/persons.png')}}" class="person" alt="" class="person-img">
                            </div>
                            <div class="col-md-12 text-center" style="margin:auto 0">
                                <p class="card-title" >- {{$Latest_Posts_per->user->name}}</p>
                            </div>
                        </div>
                    </div>

                </div>


            </div>
        </div>
    </a>
</div>
@endforeach
            </div>
            <div class="col-lg-4 col-md-12 col-sm-12" style="" class="padd-cell" id="biorgraphy-sec">
                <img src="{{url('images/persons.png')}}" id="" class="image-fluid" style="height: 200px;width:200px;display: block;margin-left: auto;margin-right: auto;width: 50%;">
                <h3 style="text-align: center" class="mt-3">{{$user->name}}</h3>
                <p  class="mt-4" style="position:sticky;top: 60;height:auto"><b>BIOGRAPHY</b><br>{{$user->biography}}</p>
            </div>
      </div>
    </div>


@endsection
@section('scripting')
    <script>
        $('.post-btn').click(function(){
           $("#biorgraphy-sec").css('display','none');
           $("#posts-section").css('display','block');
        });
        $('.biography-btn').click(function(){
           $("#posts-section").css('display','none');
           $("#biorgraphy-sec").css('display','block');
        });
    </script>
@endsection
